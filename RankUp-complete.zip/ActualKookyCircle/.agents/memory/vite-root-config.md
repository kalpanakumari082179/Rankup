---
name: Vite root config
description: How the Vite root directory is configured for the RankUp monorepo
---

# Vite Root Config

**Rule:** The root vite.config.js sets `root: 'client'`. The npm script must run `vite` (no positional arg). Do NOT run `vite client` — it sets root to `client/client`.

**Why:** Passing a directory as a CLI positional arg overrides the `root` in config, causing double-nested paths.

**How to apply:**
- npm script: `"client": "vite --port 5000 --host 0.0.0.0"`
- vite.config.js at root with `root: 'client'`
- No vite.config.js inside the `client/` directory
