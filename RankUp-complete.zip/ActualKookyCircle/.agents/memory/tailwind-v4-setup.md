---
name: Tailwind v4 setup
description: How to configure Tailwind CSS v4 with Vite in this project
---

# Tailwind v4 Setup

**Rule:** Tailwind v4 no longer uses `tailwind.config.js` or `postcss.config.js`. It uses a Vite-first approach.

**Why:** v4 moved to CSS-first config and native Vite plugin. The old PostCSS plugin still exists as a separate package but conflicts with the Vite plugin.

**How to apply:**
1. Install `@tailwindcss/vite` (NOT `@tailwindcss/postcss`)
2. Add `tailwindcss()` from `@tailwindcss/vite` to vite plugins array
3. CSS file uses `@import "tailwindcss"` (not `@tailwind base/components/utilities`)
4. Theme tokens go inside `@theme { }` block in CSS
5. Delete `postcss.config.js` and `tailwind.config.js` if present — they cause conflicts
